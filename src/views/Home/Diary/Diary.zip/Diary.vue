<template>
	<div>
		<!-- <div :style="{width: '300px', height: '300px'}" ref="myChart"></div> -->
		<el-row type="flex" justify="space-around" class="fm_div">
			<el-col :span="16">
				<div>
					<el-container>
						<el-header height="80px">
							<el-container direction="horizontal">
								<h1>日志管理</h1>
							</el-container>
						</el-header>
						<h1 class="footerdiv"></h1>
						<el-header height="120px">
							
							<el-row style="padding-top:40px; height: 40px;display: flex;flex-direction: row;">
								<p style="line-height: 30px; margin-right: 10px;">日志日期:</p>
								<el-radio-group  size="small" >
								  <el-button @click="timeSelect" size="small">全部</el-button>
								</el-radio-group>
								<el-date-picker
								style="display: flex; width: 30%;"
								v-model="timeValue"
								type="daterange"
								range-separator="至"
								start-placeholder="开始日期"
								end-placeholder="结束日期"
								size='small'
								value-format="yyyy-MM-dd"
								@change="timeChange">
								</el-date-picker>
								<a style="padding-top:5px; padding-left: 20px;" class="el-icon-download" href="http://localhost:8080/exportExlce/allOperationLog">导出日志记录</a>
							</el-row>
						</el-header>
						<el-footer height="360px" class="el-footer1">
							<h3 class="footerdiv">日志数据：</h3>
							<el-row style="height: 320px;margin-top:10px;display: flex;flex-direction: row;">
								<el-table
								:data="logData"
								style="width: 100%"
								max-height="300">
								    <el-table-column
								      prop="operationLog.logId"
								      label="日志ID"
									  align="center">
								    </el-table-column>
								    <el-table-column
								      prop="manager.managerName"
								      label="管理员姓名"
									  align="center">
								    </el-table-column>
								    <el-table-column
								      prop="operation.operationDetail"
								      label="日志操作"
									  align="center">
								    </el-table-column>
								    <el-table-column
								      prop="operationLog.operationTime"
								      label="日志日期"
									  align="center"
									  width="180">
								    </el-table-column>
								    <el-table-column
								      prop="manager.managerId"
								      label="用户ID"
									  align="center">
								    </el-table-column>
								    <el-table-column
								      fixed="right"
								      label="操作"
									  align="center">
								      <template slot-scope="scope">
								        <el-button
								          @click="EditRow(scope.$index, logData)"
								          type="text"
								          size="small"
										  class="el-icon-edit-outline">
								          查看
								        </el-button>
								      </template>
								    </el-table-column>
								</el-table>
							</el-row>
							

						</el-footer>
					</el-container>
				</div>
			</el-col>

			<el-col :span="7">
				<el-card class="box-card">
					<div slot="header" class="clearfix">
						<span>日志详细信息</span>
					</div>
					<el-row><span>日志ID:</span><span style="margin-left: 14%;" class="text item">{{info.operationLog.logId}}</span></el-row>
					<el-row><span>管理员姓名:</span><span style="margin-left: 6%;" class="text item">{{info.manager.managerName}}</span></el-row>
					<el-row><span>管理员身份证:</span><span style="margin-left: 6%;" class="text item">{{info.manager.managerIdno}}</span></el-row>
					<el-row><span>管理员性别:</span><span style="margin-left: 6%;" class="text item">{{info.manager.managerSex}}</span></el-row>
					<el-row><span>管理员ID:</span><span style="margin-left: 10%;" class="text item">{{info.manager.managerId}}</span></el-row>
					<el-row><span>日志日期:</span><span style="margin-left: 10%;" class="text item">{{info.operationLog.operationTime}}</span></el-row>
					<el-row><span>日志操作:</span><span style="margin-left: 10%;" class="text item">{{info.operation.operationDetail}}</span></el-row>
					</el-card>
			</el-col>
		</el-row>
	</div>
</template>

<script>
	export default {
		name: 'diary',
		created() {
			this.setTime();
			this.getDiary();
		},
		methods: {
		    EditRow(index, rows) {
				this.info.manager=this.logData[index].manager;
				this.info.operation=this.logData[index].operation;
				this.info.operationLog=this.logData[index].operationLog;
				this.info.drow=index;
				console.log(this.info);
		    },
			downLoad(){
				this.axios.defaults.withCredentials=true;
				this.axios.post('http://localhost:8080/exportExlce/allOperationLog',
					{
					responseType: "blob"
					//responseType:'arraybuffer'
					},
				).then(r=>{
					let fileName = 'log.xlsx';
					let fileURL = window.URL.createObjectURL(new Blob([r.data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8'}));
					let fileLink = document.createElement('a');
					fileLink.href = fileURL;
					fileLink.setAttribute('download',fileName);
					document.body.appendChild(fileLink);
					
					fileLink.click();
				}).catch(r=>{});
				
			},
			timeChange(){
				if(this.timeValue==null || this.timeValue==''){
				}else{
					this.getDiary();
				}
			},
			timeSelect(){
				this.setTime();
				this.getDiary();
			},
			setTime(){
				let nowDate=new Date();
				let yy=nowDate.getFullYear();
				let MM=(nowDate.getMonth()+1)<10?'0'+(nowDate.getMonth()+1):(nowDate.getMonth()+1);
				let dd=nowDate.getDate()<10?'0'+nowDate.getDate():nowDate.getDate();
				let formatNowDate=yy+'-'+MM+'-'+dd;
				this.timeValue=['1970-01-01',formatNowDate];
			},
			getDiary(){
				let Data={
					log_start:this.timeValue[0],
					log_end:this.timeValue[1]
				}
				this.axios.defaults.withCredentials=true;
				this.axios.post('http://localhost:8080/log/selectByDetail',Data).then(r=>{
					this.logData=[];
					for(let i=0;i<r.data.msg.operationLogs.length;i++){
						//r.data.msg.operationLogs[i].operationLog.operationTime=r.data.msg.operationLogs[i].operationLog.operationTime.substring(0,10);
						this.logData.push(r.data.msg.operationLogs[i]);
					}
					console.log(this.logData);
				});
			}
			
		},
		data() {
			return {
				info:{
					manager:'',
					operation:'',
					operationLog:'',
					drow:'',
				},
				timeValue:'',
				logData: [],
				
				
			}
		},
		 
		
	}
</script>

<style scoped>
	.el-container {
		border-radius: 40px;
	}

	.el-aside {
		background-color: #antiquewhite;
		color: #333;
		text-align: center;

	}


	.el-header {
		background-color: white;
		color: #333;
		text-align: center;
		line-height: 80px;
		border-radius: 12px;
		box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
	}

	.el-footer1 {
		background-color: antiquewhite;
		color: #333;

		line-height: 20px;
		border-radius: 12px;
		box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
		margin-top: 1%;
	}

	.el-row {
		margin-bottom: 20px;


		&:last-child {
			margin-bottom: 0;
		}
	}

	.el-col {
		border-radius: 4px;

	}

	.bg-purple {
		background: #d3dce6;
	}

	.bg-purple-light {
		background: #e5e9f2;
	}

	.grid-content {
		border-radius: 40px;
		min-height: 36px;

	}

	.fm_div {
		margin-top: 20px;
	}

	.row-bg {
		padding: 10px 0;
		background-color: #f9fafc;
	}

	.footerdiv {
		margin-top: 6px;
		margin-left: 20px;
		margin-bottom: 6px;
	}

	.rowmargin {
		margin-top: 30px;
	}

	.chart1 {
		width: '350px';
		height: '300px';
		margin-top: 30px;
	}

	.spanfloat {
		float: left;
		margin: 10px;
	}
	.text {
	   font-size: 14px;
	 }
		
	 .item {
	   margin-bottom: 10px;
	 }
		
	 .clearfix:before,
	 .clearfix:after {
	   display: table;
	   content: "";
	 }
	 .clearfix:after {
	   clear: both
	 }
		
	 .box-card {
	   width:100%;
			height: 580px;
			margin-left: 0px;
	 }
</style>
